package primeiraaula;
import java.util.Scanner;

public class PrimeiraAula {

    public static void main(String[] args) {
        /* CRT + E --> apaga uma linha
        SHIFT + CRTL + seta para baixo --> duplica uma linha
        SHIFT + ALT --> muda a linha de posição
        sout + TAB --> escreve System.out.println("")
        SHIFT + F6 --> run
        */
    
    System.out.println("Olá Mundo!!!");
        System.out.println("Java é muito fácil");
        linha();
        //declaração de variáveis
        //textos
        /*
        String nome = "Vanessa";
        nome ="Vanessa";
        */
        String nome = "Vanessa";
        System.out.println(nome); 
        System.out.println("Nome: "+nome);
        System.out.printf("%s \n", nome);
        linha(); /*chama o método criado quando esse é usado muito*/
         /*
        print pode ser usado com formatações que aceita determinados tipos de variáveis:
        %s - string
        %d - números inteiros
        %f - números flutuantes (double ou float)
        %.2f - números flutuantes com 2  casas decimais
        */
           int n1 = 5;
           int n2 = 10;
           int tot = n1 + n2;           
           
           System.out.println(nome + ": " + n1 + " + " + n2 + " = " + tot);
           linha();
           System.out.printf("%s: %d + %d = %d \n" ,nome, n1, n2, tot);
           //declaração de Floats
           float preco = 8.5f;
           System.out.println("O preço é " + preco); //impressão concatenada
           System.out.printf("O preço é %f \n", preco);//impressão formatada
           System.out.printf("O preço é %.2f\n", preco);//impressão com duas casas decimais
           linha();
           System.out.printf("A %s gastou R$%.2f no lanche hoje.\n",nome, preco);
           linha();
           
           //recebendo dados pela linha de comando
           Scanner teclado = new Scanner(System.in);
           System.out.print("Informe o nome: ");
           /*String nome2;
           nome2 = teclado.nextLine();
           */
           String nome2 = teclado.nextLine();
           System.out.printf("Olá %s, bemvinda ao Senac Nadureira!!!\n", nome2);
           linha();
           
           
           
    }
    
    
    public static void linha(){
        System.out.println("################");
            
    }
    
}
